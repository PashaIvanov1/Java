package com.gmail.aba.model;


public enum Role {
    USER,
    ADMIN;


}
